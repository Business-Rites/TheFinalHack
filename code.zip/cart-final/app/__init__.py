from flask import Flask, url_for
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_uploads import configure_uploads
from importlib import import_module
from logging import basicConfig, DEBUG, getLogger, StreamHandler
from flask_uploads import UploadSet, configure_uploads, IMAGES
from os import path


#create db instance
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'base_blueprint.login'
login_manager.login_message_category = 'info' 



def register_extensions(app):
    db.init_app(app)
    login_manager.init_app(app)

#register blueprints
def register_blueprints(app):
    for module_name in ('base', 'home','admin'):
        module = import_module('app.{}.routes'.format(module_name))
        app.register_blueprint(module.blueprint)

def configure_database(app):
    '''register models'''
    @app.before_first_request
    def initialize_database():
        db.create_all()

    def seeduser():
        seed_user = User(username="arnold404", 
                        email='arnoldkgabi@gmail.com',
                        password="password",
                        role="admin")
        db.session.add(seed_user)
        db.session.commit()

    @app.teardown_request
    def shutdown_session(exception=None):
        db.session.remove()

from app.home.routes import photos
#app factory
def create_app(config):
    app = Flask(__name__, static_folder='base/static')
    app.config.from_object(config)
    
    
#############
    #flask uploads configs
    configure_uploads(app, photos)
#############
    register_extensions(app)
    register_blueprints(app)
    configure_database(app)
    return app
