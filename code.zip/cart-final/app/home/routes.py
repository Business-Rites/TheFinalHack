#set up endpoints and system logic
from app.home import blueprint
from flask import render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app import login_manager
from app import db
from app.base.models import User, requires_roles
from app.home.models import *
from app.home.forms import *
from sqlalchemy.sql.functions import func
from jinja2 import TemplateNotFound
from flask_uploads import UploadSet, configure_uploads, IMAGES
import stripe
import secrets
photos = UploadSet('photos', IMAGES)

publishable_key='pk_test_51IrqExAEzD9lvqe8v5Jb9mADbBvuncJnH37SFoILFH9JEEj1WEBbkqtodVVvttGCU2tV0mDdNpADDDo7h0FMiBpj00PmnoL9ed'
stripe.api_key='sk_test_51IrqExAEzD9lvqe8teHgfZdLsGJB2zrEQf0NsTNUaiCbu3HswsJ5YlikuiCINhnWWQm1M5ffwr7xEQnjZYYzH8OY000H8iRMVs'

#-------------------------------------------------------------------------------------------------#
#                                             SHOP ROUTES                                         #
#-------------------------------------------------------------------------------------------------#

@blueprint.route('/payment/<invoice>',methods=['POST'])
@login_required
def payment(invoice):
    amount = request.form.get('amount')
    customer = stripe.Customer.create(
      email=request.form['stripeEmail'],
      source=request.form['stripeToken'],
    )

    charge = stripe.Charge.create(
      customer=customer.id,
      description='Safe and Secure Payments',
      amount=amount,
      currency='usd',
    )
    orders =  Order.query.filter_by(user_id =current_user.id,invoice=invoice).order_by(Order.id.desc()).first()
    orders.status = 'Paid'
    db.session.commit()

    data_cart = Cart.query.filter_by(userid = current_user.id).all()
    for i in data_cart:
        db.session.delete(i)
        db.session.commit()
    return redirect(url_for('home_blueprint.ordercomplete'))

@blueprint.route('/ordercomplete')
@login_required
def ordercomplete():
    return render_template('front-order.html')


def categories():
    categories = Category.query.all()
    return categories

def brands():    
    brands = Brand.query.all()
    return brands

def fexp_type():
    vexp_type = Exp_type.query.all()
    return vexp_type

def fasset_type():
    vassettype = Asset_type.query.all()
    return vassettype

def cart_alert():
    if current_user.is_authenticated:
        cart_items = Cart.query.filter_by(userid = current_user.id).all()
        cart_items = len(cart_items)
    else:
        cart_items = int(0)
    return cart_items

@blueprint.route('/')
@blueprint.route('/home', methods=['GET', 'POST'])
def home():
    data = Product.query.all()
    new_arrivals = Product.query.filter_by(tag="newArrivals").limit(8).all()
    quadMicrowaves = Product.query.filter_by(tag="quadMicrowaves").limit(8).all()
    quadBarFridges = Product.query.filter_by(tag="quadBarFridges").limit(8).all()
    featuredPro = Product.query.filter_by(tag="featuredProducts").limit(8).all()
    return render_template('front-home.html', quadMicrowaves=quadMicrowaves, quadBarFridges=quadBarFridges, featuredPro=featuredPro,data=data, new_arrivals=new_arrivals,cart_items=cart_alert(), categories=categories(),brands=brands())


@blueprint.route('category/<int:category_id>', methods=['GET', 'POST'])
def category_filter(category_id):
    category_name = Category.query.filter_by(id = category_id).first()
    category_filter = Product.query.filter_by(category_id = category_id).all()
    return render_template('category-filter.html', cart_items=cart_alert(),category_name=category_name, categories=categories(),brands=brands(),category_filter=category_filter)


@blueprint.route("store/<int:product_id>", methods=['GET', 'POST'])
@login_required
def view_product(product_id):
    form = AddToCart()
    product = Product.query.get_or_404(product_id)
    return render_template('front-product.html', product = product, form=form,cart_items =cart_alert(), categories=categories(),brands=brands())


@blueprint.route('/cart', methods=['GET', 'POST'])
@login_required
def cart():
    #Product.query.filter_by().limit(4).all()
    data = Cart.query.filter_by(userid = current_user.id).all()
    y = []
    for x in data:
        y.append(x.cart_product.price)
    total = sum(y)
    #total = db.session.query(func.sum(data.cart_product.price)).scalar()
    return render_template('front-cart.html',data=data, cart_items = cart_alert(), total=total,categories=categories(),brands=brands())

@blueprint.route("/addToCart/<int:product_id>/", methods=['GET', 'POST'])
@login_required
def addToCart(product_id):
    form = AddToCart()
    if current_user.is_authenticated:
        if form.quantity.data:
            cart_item = Cart(userid = current_user.id, productid=product_id, quantity=form.quantity.data)
            db.session.add(cart_item)
            db.session.commit()
            #flash('Item successfully added to cart !!', 'success')
            return redirect(url_for('home_blueprint.cart'))
        else:
            cart_item = Cart(userid = current_user.id, productid=product_id, quantity=1)
            db.session.add(cart_item)
            db.session.commit()
            #flash('Item successfully added to cart !!', 'success')
            return redirect(url_for('home_blueprint.cart'))           
    else:
        return redirect(url_for('base_blueprint.login'))

@blueprint.route("shop/delete/<int:cart_id>", methods=['DELETE','POST','GET'])
@login_required
def delete_cart(cart_id):
    cart_item = Cart.query.get_or_404(cart_id)
    db.session.delete(cart_item)
    db.session.commit()
    return redirect(url_for('home_blueprint.cart'))



@blueprint.route('/shipping', methods=['GET', 'POST'])
@login_required
def shipping():
    form = CustomerForm()
    cust = Customer.query.get_or_404(current_user.id)
    if form.validate_on_submit():
        
        custData = Customer(firstName=form.firstName.data,
                            lastName=form.lastName.data, 
                            phone=form.phone.data, 
                            companyName=form.companyName.data,
                            postalAddress=form.postalAddress.data,
                            streetAddress=form.streetAddress.data, 
                            addInfo=form.addInfo.data, 
                            user_id=current_user.id
                            )

        db.session.add(custData)
        db.session.commit()
        #flash('Entry successfully!','success')
        return redirect(url_for('home_blueprint.checkout'))

    elif request.method == 'GET':
        form.firstName.data = cust.firstName
        form.lastName.data = cust.lastName
        form.phone.data = cust.phone
        form.companyName.data = cust.companyName
        form.postalAddress.data = cust.postalAddress
        form.streetAddress.data = cust.streetAddress
    return render_template('front-shipping.html', cart_items=cart_alert(),form=form)



def handle_cart():
    products = []
    grand_total = 0
    index = 0
    quantity_total = 0

    cart_items = Cart.query.filter_by(userid = current_user.id).all()

    for item in cart_items:
        product = Product.query.filter_by(id=item.id).first()

        quantity = int(item.quantity)
        total = quantity * product.price
        grand_total += total

        quantity_total += quantity

        products.append({'id' : product.id, 'name' : product.name, 'price' :  product.price, 'quantity' : quantity, 'total': total, 'index': index})
        index += 1

    return products, grand_total, quantity_total



'''
@blueprint.route("/getorder", methods=['GET','POST'])
@login_required
def createOrder():
    if current_user.is_authenticated:
        customer_id = current_user.id
        invoice = secrets.token_hex(5)
        products, grand_total, quantity_total = handle_cart()
        order = Order()
        order.invoice = invoice
        order.user_id = customer_id

        for product in products:
            order_item = Order_Item(quantity=product['quantity'], product_id=product['id'])
            order.items.append(order_item)

            product = Product.query.filter_by(id=product['id']).update({'stock' : Product.stock - product['quantity']})
        db.session.add(order)
        db.session.commit()

        return redirect(url_for('home_blueprint.checkout'))
''' 

@blueprint.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    if current_user.is_authenticated:
        customer_id = current_user.id
        invoice = secrets.token_hex(5)
        products, grand_total, quantity_total = handle_cart()
        order = Order()
        order.invoice = invoice
        order.user_id = customer_id

        for product in products:
            order_item = Order_Item(quantity=product['quantity'], product_id=product['id'])
            order.items.append(order_item)

            product = Product.query.filter_by(id=product['id']).update({'stock' : Product.stock - product['quantity']})
        db.session.add(order)
        db.session.commit()

    grand_amount = ("%.2f" % (float(grand_total)))
    return render_template('front-checkout.html', cart_items=cart_alert(),grand_amount=grand_amount,products=products,invoice=invoice)


#-------------------------------------------------------------------------------------------------#
#                                             Services ROUTES                                     #
#-------------------------------------------------------------------------------------------------#

@blueprint.route('/req-service', methods=['GET', 'POST'])
@login_required

def req_service():
    form = reqServiceForm()
    if form.validate_on_submit():

        reqServiceData = ServiceReq(serviceProduct=form.serviceProduct.data,
                                    serviceType=form.serviceType.data, 
                                    description=form.description.data, 
                                    address=form.address.data,
                                    callOut=form.callOut.data,
                                    appoinmentDate=form.appointment.data,
                                    user_id=current_user.id)

        db.session.add(reqServiceData)
        db.session.commit()
        flash('Request sent successfully!','success')
        return redirect(url_for('home_blueprint.req_service'))
    data = ServiceReq.query.filter_by(user_id=current_user.id).all()
    return render_template('req-service.html', form=form, data=data, cart_items=cart_alert(), categories=categories(),brands=brands())





@blueprint.route("/get_comment/<int:post_id>", methods=['GET', 'POST'])
@login_required
def get_comment(post_id):
    comments = Comments.query.filter_by(posts = post_id).all()
    return comments


@blueprint.route("/req-service/<int:service_id>", methods=['GET', 'POST'])
@login_required
def single_service(service_id):
    post_form = PostForm()
    comment_form = CommentForm()
    posts = Posts.query.filter_by(service_id = service_id).all()
    service = ServiceReq.query.get_or_404(service_id)
    return render_template('single-service.html',post_form=post_form,
                                                service_id=service_id,
                                                comment_form=comment_form, 
                                                service = service,
                                                posts = posts,
                                                cart_items =cart_alert(), 
                                                categories=categories(),
                                                brands=brands())


@blueprint.route("/add_post/<int:service_id>", methods=['GET','POST'])
@login_required
def add_post(service_id):
    post_form = PostForm()
    if post_form.validate_on_submit():

        vpost = Posts(title=post_form.title.data,
                      content=post_form.content.data,
                      user_id = current_user.id,
                      service_id=service_id
                    )
        db.session.add(vpost)
        db.session.commit()
        flash('Message sent successfully', 'success')
        return redirect(url_for('home_blueprint.req_service'))


@blueprint.route("/add_comment/<int:post_id>", methods=['GET','POST'])
@login_required
def add_comment(post_id):
    comment_form = CommentForm()
    if comment_form.validate_on_submit():

        vcomment = Comments(content=comment_form.content.data,
                      user_id = current_user.id,
                      posts=post_id
                    )
        db.session.add(vcomment)
        db.session.commit()
        flash('Message sent successfully', 'success')
        return redirect(url_for('home_blueprint.req_service'))


@blueprint.route("/req-service-dashboard")
def req_service_dashboard():
    cart_items = Cart.query.filter_by(userid = current_user.id).all()
    data = ReqService.query.all()
    return render_template('req-service-dash.html',data=data, cart_items=cart_alert(), categories=categories(),brands=brands())

@blueprint.route("/services")
@login_required
def services_home():
    return render_template('services-home.html', cart_items=cart_alert(), categories=categories(),brands=brands())

#-------------------------------------------------------------------------------------------------#
#                                             ManageServices ROUTES                               #
#-------------------------------------------------------------------------------------------------#
@blueprint.route('/services-all')
@login_required
@requires_roles('admin','emp')
def xServiceReq():
    form = ServiceInvForm()
    data = ServiceReq.query.filter_by(user_id=current_user.id).all()
    return render_template('xServicesDash.html',data=data,form=form)

@blueprint.route('/services-invoice/<int:service_id>')
@login_required
@requires_roles('admin','emp')
def service_invoice(service_id):
    form = ServiceInvForm()
    inv= ServiceInv(
                    invDesc=form.invDesc.data,
                    invPrice=form.amount.data,
                    invStatus='pending',
                    service_id=service_id
        )
    db.session.add(inv)
    db.session.commit()
    return redirect(url_for('home_blueprint.xServiceReq'))



@blueprint.route("/service-focus/<int:service_id>", methods=['GET', 'POST'])
@login_required
@requires_roles('admin','emp')
def xsingle_service(service_id):
    post_form = PostForm()
    comment_form = CommentForm()
    posts = Posts.query.filter_by(service_id = service_id).all()
    service = ServiceReq.query.get_or_404(service_id)
    return render_template('xservice-focus.html',post_form=post_form,
                                                service_id=service_id,
                                                comment_form=comment_form, 
                                                service = service,
                                                posts = posts)



#-------------------------------------------------------------------------------------------------#
#                                             ManageShop ROUTES                                   #
#-------------------------------------------------------------------------------------------------#



@blueprint.route('/addattributes', methods=['GET', 'POST'])
@login_required
@requires_roles('admin','emp')
def addattributes():
    categoryform = AddCategory()
    brandform = AddBrand()
    print('url found')
    return render_template('add-attributes.html', categoryform=categoryform, brandform=brandform)


@blueprint.route("/addbrand", methods=['POST'])
def addbrand():
    brandform = AddBrand()
    if brandform.validate_on_submit():
        brand_name = Brand(name = brandform.name.data)
        db.session.add(brand_name)
        db.session.commit()
        flash(f'Brand {brand_name} has been added successfully!!', 'success')
        return redirect(url_for('home_blueprint.addattributes'))


@blueprint.route("/addcategory", methods=['POST'])
def addcategory():
    categoryform = AddCategory()
    if categoryform.validate_on_submit():
        name = categoryform.name.data
        category_name = Category(name = name)
        db.session.add(category_name)
        db.session.commit()
        flash(f'Category {name} has been added successfully!!', 'success')
        return redirect(url_for('home_blueprint.addattributes'))


@blueprint.route('/shop/manage', methods=['GET', 'POST'])
@login_required
def manage_shop():
    data = Product.query.all()
    new_arrivals = Product.query.filter_by().limit(4).all()
    return render_template('manage_shop.html', data = data)


@blueprint.route("shop/add-product", methods=['GET', 'POST'])
@login_required
def add_product():
    form = AddproductForm()
    Categories = Category.query.all()
    Brands = Brand.query.all()
    if form.validate_on_submit():
        brand = request.form.get('brand')
        category = request.form.get('category')
        image1_url = photos.url(photos.save(form.image1.data))
        image2_url = photos.url(photos.save(form.image2.data))
        image3_url = photos.url(photos.save(form.image3.data))
        print(brand, category)
        new_product = Product(name=form.name.data, price=form.price.data,
                             stock=form.stock.data, tag=request.form.get('tags'),
                             discount=form.discount.data,
                             description=form.description.data, image_1=image1_url, 
                             image_2=image2_url, image_3=image3_url,
                             category_id = category,brand_id=brand)
        db.session.add(new_product)
        db.session.commit()
        flash('Product added successfully!','success')
        return redirect(url_for('home_blueprint.add_product'))
    return render_template("add-product.html", form=form, Categories=Categories, Brands=Brands)


@blueprint.route("shop/<int:product_id>/update", methods=['GET', 'POST'])
@login_required
def update_product(product_id):
    product = Product.query.get_or_404(product_id)
    form = UpdateproductForm()
    if form.validate_on_submit():
        image_url = photos.url(photos.save(form.image.data))
        product.name = form.name.data
        product.price = form.price.data
        product.stock = form.stock.data
        product.description = form.description.data
        product.image = image_url
        db.session.commit()
        flash('Product Updated successfully!','success')
        return redirect(url_for('home_blueprint.manage_shop'))
    elif request.method == 'GET':
        form.name.data = product.name
        form.price.data = product.price
        form.stock.data = product.stock
        form.description.data = product.description
        form.image.data = product.image
    return render_template("update-product.html", form=form)


@blueprint.route("shop/<int:product_id>/delete", methods=['POST'])
@login_required
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash('Entry has been deleted!', 'success')
    return redirect(url_for('home_blueprint.manage_shop'))


#-------------------------------------------------------------------------------------------------#
#                                             Company ROUTES                                      #
#-------------------------------------------------------------------------------------------------#


@blueprint.route('/index')
@login_required
@requires_roles('admin','emp')
def index():
    revenue1 = db.session.query(func.sum(Sales.product_code)).scalar()
    #revenue1 = db.session.execute(Sales.query.with_entities(func.sum(Sales.product_code).label('sum')).filter())
    #revenue = db.session.execute(Sales.query(func.sum(Sales.product_code).label('Price')))
    return render_template('index.html',revenue=revenue1)


@blueprint.route('/quickquote', methods=['GET', 'POST'])
@login_required
def quotation():
    form = QuotationForm()
    if form.validate_on_submit():
        
        quotationData = Quotation(quoProduct=form.quoProduct.data,
                                    quoQuantity=form.quoQuantity.data, 
                                    quoPrice=form.quoPrice.data, 
                                    quoAddDiscount=form.quoAddDiscount.data,
                                    quoNotes_Terms=form.quoNotes_Terms.data)

        db.session.add(quotationData)
        db.session.commit()
        flash('Entry successfully!','success')
        return redirect(url_for('home_blueprint.index'))

    return render_template('quotation.html', form=form)

@blueprint.route('/company', methods=['GET', 'POST'])
@login_required
def company():
    form = CompanyProfileForm()
    if form.validate_on_submit():

        companyProfileData = CompanyProfile(cmpyName=form.cmpyName.data,
                                    cmpyEmail=form.cmpyEmail.data, 
                                    cmpyPlotNo=form.cmpyPlotNo.data, 
                                    cmpyCity=form.cmpyCity.data,
                                    cmpyCountry=form.cmpyCountry.data,
                                    cmpyAddress=form.cmpyAddress.data, 
                                    cmpyPhone=form.cmpyPhone.data, 
                                    cmpyBankName=form.cmpyBankName.data,
                                    cmpyBeneficiaryName=form.cmpyBeneficiaryName.data, 
                                    cmpyBeneficiaryAccNo=form.cmpyBeneficiaryAccNo.data, 
                                    cmpyBankBranchNo=form.cmpyBankBranchNo.data)

        db.session.add(companyProfileData)
        db.session.commit()
        flash('Entry successfully!','success')
        return redirect(url_for('home_blueprint.index'))
    return render_template('company-profile.html', form=form)

@blueprint.route("/sales-dashboard")
def sales_dashboard():
    data = Sales.query.all()
    return render_template('sales.html',data=data)

@blueprint.route("/acc-exp")
def acc_exp():
    data = Expenses.query.all()
    return render_template('acc-exp.html',data=data)


#############################################
@blueprint.route("/acc-list")
def acc_list():
    exp_sum = db.session.query(func.sum(Expenses.amount)).scalar()
    if exp_sum==None:
        exp_sum = 0

    sales_sum = db.session.query(func.sum(Sales.amount)).scalar()
    if sales_sum==None:
        sales_sum = 0

    pur_sum = db.session.query(func.sum(Purchases.amount)).scalar()
    if pur_sum==None:
        pur_sum = 0
        
    ass_sum = db.session.query(func.sum(Fixed_assets.amount)).scalar()
    if ass_sum==None:
        ass_sum = 0


    return render_template('acc-list.html',
                            exp_sum=exp_sum,
                            sales_sum=sales_sum,
                            pur_sum=pur_sum,
                            ass_sum=ass_sum)

@blueprint.route("/purchases-dashboard")
def purchases_dashboard():
    data = Purchases.query.all()
    return render_template('purchases.html',data=data)


@blueprint.route("/sales-charts")
def sales_charts():
    
    return render_template('sales-charts.html')

@blueprint.route("/marketing-charts")
def marketing_charts():
    
    return render_template('marketing-charts.html')

@blueprint.route("/services-charts")
def services_charts():


    return render_template('services-charts.html')

@blueprint.route("/gservices")
def gservices():


    return render_template('gservices.html')


@blueprint.route("/gproducts")
def gproducts():


    return render_template('gproducts.html')

#-------------------------------------------------------------------------------------------------#
#                                             ACCO ROUTES                                         #
#-------------------------------------------------------------------------------------------------#




@blueprint.route("sales/add", methods=['GET', 'POST'])
@login_required
@requires_roles('admin','emp')
def add_sales():
    form = AddsalesForm()
    if form.validate_on_submit():
        sales = Sales(
                    cust_fname = form.cust_fname.data,
                    cust_lname = form.cust_lname.data,
                    email = form.email.data,
                    cust_phone_no = form.cust_phone_no.data,
                    product_code = form.product_code.data,
                    qnt = form.qnt.data,
                    warranty_status = form.warranty_status.data,
                    delivery = form.delivery.data,
                    author=current_user)
        db.session.add(sales)
        db.session.commit()
        flash('Entry completed successfully!','success')
        return redirect(url_for('home_blueprint.add_sales'))    
    return render_template("add-sales.html", form=form)



@blueprint.route("purchase/add", methods=['GET', 'POST'])
@login_required
@requires_roles('admin','emp')
def add_purchases():
    form = AddpurchaseForm()
    if form.validate_on_submit():
        purchases = Purchases(
                    product_name = form.product_name.data,
                    product_code = form.product_code.data,
                    pro_qnt = form.pro_qnt.data,
                    pro_price = form.pro_price.data,
                    payment_terms = form.payment_terms.data)
        db.session.add(purchases)
        db.session.commit()
        flash('Entry completed successfully!','success')
        return redirect(url_for('home_blueprint.add_purchases'))    
    return render_template("add-purchases.html", form=form)



@blueprint.route("sales/<int:sales_id>/update", methods=['GET', 'POST'])
@login_required
@requires_roles('admin','emp')
def update_sales(sales_id):
    sales = Sales.query.get_or_404(sales_id)
    if sales.author != current_user:
        abort(403)
    form = UpdatesalesForm()
    if form.validate_on_submit():
        sales.cust_fname = form.cust_fname.data
        sales.cust_lname = form.cust_lname.data
        sales.email = form.email.data
        sales.cust_phone_no = form.cust_phone_no.data
        sales.product_code = form.product_code.data
        sales.qnt = form.qnt.data
        sales.warranty_status = form.warranty_status.data
        sales.delivery = form.delivery.data
        db.session.commit()
        flash('Entry Updated successfully!','success')
        return redirect(url_for('home_blueprint.sales_dashboard'))
    elif request.method == 'GET':
        form.cust_fname.data = sales.cust_fname
        form.cust_lname.data = sales.cust_lname
        form.email.data = sales.email
        form.cust_phone_no.data = sales.cust_phone_no
        form.product_code.data = sales.product_code
        form.qnt.data = sales.qnt
        form.warranty_status.data = sales.warranty_status
        form.delivery.data = sales.delivery
    return render_template("update-sales.html", form=form)

@blueprint.route("sales/<int:sales_id>/delete", methods=['POST'])
@login_required
@requires_roles('admin','emp')
def delete_sales(sales_id):
    sales = Sales.query.get_or_404(sales_id)
    if sales.author != current_user:
        abort(403)
    db.session.delete(sales)
    db.session.commit()
    flash('Entry has been deleted!', 'success')
    return redirect(url_for('home_blueprint.manage_shop'))


@blueprint.route("/exp_type", methods=['POST'])
def exp_type():
    form = exp_typeForm()
    if form.validate_on_submit():
        exptype = Exp_type(name=form.exptype.data)
        db.session.add(exptype)
        db.session.commit()
        flash('Exp Type added successfully!','success')
        return redirect(url_for('home_blueprint.add_expense'))

@blueprint.route("/asset_type",methods=['POST'])
def asset_type():
    form = asset_typeForm()
    if form.validate_on_submit():
        assettype = Asset_type(name=form.assetType.data)
        db.session.add(assettype)
        db.session.commit()
        flash(f'{form.assetType.data} added successfully!','success')
        return redirect(url_for('home_blueprint.add_FixedAsset'))


@blueprint.route("/add_expense",methods=['GET','POST'])
def add_expense():
    form = add_expenseForm()
    exp_typeform = exp_typeForm()
    if form.validate_on_submit():
        expense = Expenses(exp_type=request.form.get('exp_type'),
                           description=form.description.data,
                           paymentStatus=request.form.get('ex_paymentStatus'),
                           payment_method=request.form.get('ex_paymentMethod'),
                           amount=form.amount.data,
                           date=form.date.data
                            )
        db.session.add(expense)
        db.session.commit()
        flash('Expense added successfully!','success')
        return redirect(url_for('home_blueprint.add_expense'))

    return render_template('acc-addExp.html',exptypes=fexp_type(),
                                            exp_typeform=exp_typeform,
                                            form=form
                                            )



@blueprint.route("/add_FixedAsset",methods=['GET','POST'])
def add_FixedAsset():
    form = add_FixedAssetForm()
    asset_typeform = asset_typeForm()
    if form.validate_on_submit():
        asset = Fixed_assets(name=form.name.data,
                             description=form.description.data,
                             paymentStatus=request.form.get('as_paymentStatus'),
                             payment_method=request.form.get('as_paymentMethod'),
                             usefulLife=form.usefulLife.data,
                             amount=form.amount.data,
                             assetType=request.form.get('as_asset_type'),
                             date=form.date.data
                             )
        db.session.add(asset)
        db.session.commit()
        flash('Asset added successfully!','success')
        return redirect(url_for('home_blueprint.add_FixedAsset'))

    return render_template('acc-addFasset.html',asset_types=fasset_type(), 
                                                asset_typeform= asset_typeform,
                                                form=form)

@blueprint.route("/generalLedger")
def generalLedger():
    ''' expense queries and sums '''
    vtest = Expenses.query.with_entities(Expenses.exp_type, func.sum(Expenses.amount).label('exp_amount')).group_by(Expenses.exp_type).subquery()
    ytest = Expenses.query.with_entities(Exp_type, vtest.c.exp_amount).outerjoin(vtest, Exp_type.id == vtest.c.exp_type).order_by(Exp_type.id)
    exp_sum = db.session.query(func.sum(Expenses.amount)).scalar()

    ''' expense queries and sums '''
    vtest1 = Fixed_assets.query.with_entities(Fixed_assets.assetType, func.sum(Fixed_assets.amount).label('asset_amount')).group_by(Fixed_assets.assetType).subquery()
    ytest1 = Fixed_assets.query.with_entities(Asset_type, vtest1.c.asset_amount).outerjoin(vtest1, Asset_type.id == vtest1.c.assetType).order_by(Asset_type.id)
    asset_sum = db.session.query(func.sum(Fixed_assets.amount)).scalar()

    ''' cash queries '''
    #vmain = Expenses.query.with_entities(Expenses.payment_method, func.sum(Expenses.amount).label('main_amount')).group_by(Expenses.payment_method).all()
    #vmain = Fixed_assets.query.with_entities(Fixed_assets.payment_method, func.sum(Fixed_assets.amount).label('main_amount')).group_by(Fixed_assets.payment_method).all()
    cExps = Expenses.query.filter_by(payment_method = 'Cash').all()
    bExps = Expenses.query.filter_by(payment_method = 'Bank').all()
    cFxds = Fixed_assets.query.filter_by(payment_method = 'Cash').all()
    bFxds = Fixed_assets.query.filter_by(payment_method = 'Bank').all()


    temp = []
    for cExp in cExps:
        temp.append(int(cExp.amount))
    cash_exp = sum(temp)

    temp1 = []
    for bExp in bExps:
        temp1.append(int(bExp.amount))
    bank_exp = sum(temp1)

    temp2 = []
    for cFxd in cFxds:
        temp2.append(int(cFxd.amount))
    cash_Fxd = sum(temp2)

    temp3 = []
    for bFxd in bFxds:
        temp3.append(int(bFxd.amount))
    bank_Fxd = sum(temp3)

    cash_credit = cash_exp + cash_Fxd
    cash_debit = 0
    bank_credit = bank_exp + bank_Fxd
    bank_debit = 0
    totalCr = cash_credit + bank_credit
    totalDr = exp_sum + asset_sum
    return render_template('acc-GL.html',ytest=ytest,ytest1=ytest1,
                                         cash_credit=cash_credit,
                                         bank_credit = bank_credit,
                                         bank_debit = bank_debit,
                                         cash_debit=cash_debit, 
                                         totalDr=totalDr,
                                         totalCr = totalCr)




'''
def fexp_type():
    vexp_type = Exp_type.query.all()
    return vexp_type

def fasset_type():
    vassettype = Asset_type.query.all()
    return vassettype
'''


#-------------------------------------------------------------------------------------------------#
#                                             GENERAL ROUTES                                      #
#-------------------------------------------------------------------------------------------------#

@blueprint.route('/aboutUs')
@login_required
def aboutUs():
    return render_template('about-us.html',cart_items=cart_alert(), categories=categories(),brands=brands())

@blueprint.route('/contactUs')
@login_required
def contactUs():
    return render_template('contact-us.html',cart_items=cart_alert(), categories=categories(),brands=brands())

@blueprint.route('/termsconditions')
@login_required
def termsconditions():
    return render_template('terms&conditions.html',cart_items=cart_alert(), categories=categories(),brands=brands())

@blueprint.route('/guides')
@login_required
def guides():
    return render_template('guides.html',cart_items=cart_alert(), categories=categories(),brands=brands())

@blueprint.route('/privacy')
@login_required
def privacy():
    return render_template('privacy.html',cart_items=cart_alert(), categories=categories(),brands=brands())

@blueprint.route('/returns')
@login_required
def returns():
    return render_template('returns.html',cart_items=cart_alert(), categories=categories(),brands=brands())






@blueprint.route('/<template>')
@login_required
def route_template(template):

    try:

        if not template.endswith( '.html' ):
            template += '.html'

        # Detect the current page
        segment = get_segment( request )

        # Serve the file (if exists) from app/templates/FILE.html
        return render_template( template, segment=segment )

    except TemplateNotFound:
        return render_template('page-404.html'), 404
    
#    except:
#        return render_template('page-500.html'), 500

# Helper - Extract current page name from request 
def get_segment( request ): 

    try:

        segment = request.path.split('/')[-1]

        if segment == '':
            segment = 'index'

        return segment    

    except:
        return None  
