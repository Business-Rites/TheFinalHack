#create db models/tables
from sqlalchemy import Binary, Column, Integer, String, Text, Sequence
from datetime import datetime

from app import db

#--------------------------------------------------------------------------------------------------------------------#
#                                              Database Models                                                       #
#--------------------------------------------------------------------------------------------------------------------#

class CompanyProfile(db.Model):
    id = Column(Integer, primary_key=True)
    cmpyName = db.Column(db.String(50))
    cmpyEmail = db.Column(db.String(150))
    cmpyPlotNo = db.Column(db.String(150))
    cmpyCity = db.Column(db.String(150))
    cmpyCountry = db.Column(db.String(150))
    cmpyAddress = db.Column(db.String(150))
    cmpyPhone = db.Column(db.Integer)
    cmpyBankName = db.Column(db.String(255))
    cmpyBeneficiaryName = db.Column(db.String(255))
    cmpyBeneficiaryAccNo = db.Column(db.Integer)
    cmpyBankBranchNo = db.Column(db.Integer)


class Quotation(db.Model):
    id = Column(Integer, primary_key=True)
    quoNo = db.Column(db.String(255))
    quoDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    quoProduct = db.Column(db.String(255))
    quoQuantity = db.Column(db.Integer)
    quoPrice = db.Column(db.Integer)
    quoAddDiscount = db.Column(db.Integer)
    quoNotes_Terms = db.Column(db.String(255))

class Invoice(db.Model):
    id = Column(Integer, primary_key=True)
    invNo = db.Column(db.String(255))
    invDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    invDueDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)   
    invProduct = db.Column(db.String(255))
    invQuantity = db.Column(db.Integer)
    invPrice = db.Column(db.Integer)
    invAddDiscount = db.Column(db.Integer)
    invNotes_Terms = db.Column(db.String(255))

class Receipts(db.Model):
    id = Column(Integer, primary_key=True)
    recNo = db.Column(db.String(255))
    recDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    recProduct = db.Column(db.String(255))
    recQuantity = db.Column(db.Integer)
    recPrice = db.Column(db.Integer)
    recNotes_Terms = db.Column(db.String(255))

class ServiceReq(db.Model):
    
    __tablename__ = 'ServiceReq'

    id = Column(Integer, primary_key=True)
    serviceProduct = db.Column(db.String(255))
    serviceType =  db.Column(db.String(255))
    description =  db.Column(db.String(255))
    address = db.Column(db.String(255))
    callOut = db.Column(db.String(255))
    status = db.Column(db.String(255), default='Pending')
    appoinmentDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    requestDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'), nullable=False)
    
    posts = db.relationship('Posts', backref='vposts', lazy=True)

class ServiceInv(db.Model):
    id = Column(Integer, primary_key=True)
    invNo = db.Column(Integer, db.Sequence('invNo', start=100, increment=1))
    invDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    invDueDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)   
    invDesc = db.Column(db.String(255))
    invStatus = db.Column(db.Integer)
    invPrice = db.Column(db.Integer)
    service_id = db.Column(db.Integer, db.ForeignKey('ServiceReq.id'), nullable=False)


class Posts(db.Model):

    __tablename__ = 'Posts'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('ServiceReq.id'), nullable=False)
    comments = db.relationship('Comments', backref='vcomments', lazy=True)

class Comments(db.Model):

    __tablename__ = 'Comments'

    id = db.Column(db.Integer, primary_key=True)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'), nullable=False)
    posts = db.Column(db.Integer, db.ForeignKey('Posts.id'), nullable=False)

###############################################################################
class Sales(db.Model):

    __tablename__ = 'Sales'

    id = Column(Integer, primary_key=True)
    product_code = db.Column(db.String(10))
    qnt = db.Column(db.String(10))
    warranty_status = db.Column(db.String(10))
    delivery = db.Column(db.String(10))
    discount = db.Column(db.String(10))
    payment_method = db.Column(db.String(255))
    amount = db.Column(db.String(10))
    date_added = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    customer = db.Column(db.Integer, db.ForeignKey('Pos_Customer.id',name='fk_sale_pos_cust_id'), nullable=True)
    seller = db.Column(db.Integer, db.ForeignKey('User.id',name='fk_sale_user_id'), nullable=False)

    def __repr__(self):
        return str(self.cust_fname,self.email)


class Pos_Customer(db.Model):

    __tablename__ = 'Pos_Customer'

    id = Column(Integer, primary_key=True)
    fullName = db.Column(db.String(255))
    email = db.Column(db.String(255))
    cust_phone_no = db.Column(db.String(50))



class Purchases(db.Model):

    __tablename__ = 'Purchases'

    id = Column(Integer, primary_key=True)
    product_name = db.Column(db.String(255))
    product_code = db.Column(db.String(50))
    pro_qnt = db.Column(db.String(10))
    paymentStatus = db.Column(db.String(255))
    amount = db.Column(db.String(10))
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    sup_id = db.Column(db.Integer, db.ForeignKey('Supplier.id',name='fk_sup_purchases_id'),nullable=True)


class Supplier(db.Model):

    __tablename__ = 'Supplier'

    id = Column(Integer, primary_key=True)
    sup_name = db.Column(db.String(255))
    sup_email = db.Column(db.String(255))
    sup_phone_no = db.Column(db.String(50))
    address = db.Column(db.String(10))
    purchases = db.relationship('Purchases', backref='purchases_author', lazy=True)


class Exp_type(db.Model):

    __tablename__ = 'Exp_type'

    id = Column(Integer, primary_key=True)
    name = db.Column(db.String(255))
    exp = db.relationship('Expenses', backref='exp_arthor', lazy=True)

class Expenses(db.Model):

    __tablename__ = 'Expenses'

    id = Column(Integer, primary_key=True)
    exp_type = db.Column(db.Integer, db.ForeignKey('Exp_type.id',name='fk_exp_exptype_id'),nullable=False)
    description = db.Column(db.String(255))
    paymentStatus = db.Column(db.String(255))
    payment_method = db.Column(db.String(255))
    amount = db.Column(db.String(10))
    supplier = db.Column(db.Integer, db.ForeignKey('Supplier.id',name='fk_exp_supl_id'),nullable=True)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)



class Fixed_assets(db.Model):

    __tablename__ = 'Fixed_assets'

    id = Column(Integer, primary_key=True)
    name = db.Column(db.String(255))
    description = db.Column(db.String(255))
    paymentStatus = db.Column(db.String(255))
    payment_method = db.Column(db.String(255))
    usefulLife = db.Column(db.String(5))
    amount = db.Column(db.String(10))
    assetType = db.Column(db.Integer, db.ForeignKey('Asset_type.id',name='fk_fixed_asset_assettype_id'),nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    supplier = db.Column(db.Integer, db.ForeignKey('Supplier.id',name='fk_fixed_supl_id'),nullable=True)

class Asset_type(db.Model):

    __tablename__ = 'Asset_type'

    id = Column(Integer, primary_key=True)
    name = db.Column(db.String(255))
    
########################################################################################## 

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True)
    price = db.Column(db.Integer) #in cents
    discount = db.Column(db.Integer, default=0)
    stock = db.Column(db.Integer)
    tag = db.Column(db.String(150))
    description = db.Column(db.String(500))
    image_1 = db.Column(db.String(150))
    image_2 = db.Column(db.String(150))
    image_3 = db.Column(db.String(150))    
    date = db.Column(db.DateTime, nullable=False,default=datetime.utcnow)

    category_id = db.Column(db.Integer, db.ForeignKey('category.id'),nullable=False)
    brand_id = db.Column(db.Integer, db.ForeignKey('brand.id'),nullable=False)

    cart = db.relationship('Cart', backref='cart_product', lazy=True)
    orders = db.relationship('Order_Item', backref='product', lazy=True)

class Brand(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=True, nullable=False)
    
    product = db.relationship('Product', backref='brand', lazy=True)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=True, nullable=False)

    product = db.relationship('Product', backref='category', lazy=True)


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice = db.Column(db.String(20))
    status = db.Column(db.String(20), default='Pending', nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'), nullable=False)

    items = db.relationship('Order_Item', backref='order', lazy=True)

    def order_total(self):
        return db.session.query(db.func.sum(Order_Item.quantity * Product.price)).join(Product).filter(Order_Item.order_id == self.id).scalar() + 1000

    def quantity_total(self):
        return db.session.query(db.func.sum(Order_Item.quantity)).filter(Order_Item.order_id == self.id).scalar()

class Order_Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    quantity = db.Column(db.Integer)

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.Integer, db.ForeignKey('User.id'), nullable=False)
    productid = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstName = db.Column(db.String(255))
    lastName = db.Column(db.String(255))
    phone = db.Column(db.String(255))
    companyName = db.Column(db.String(255))
    postalAddress = db.Column(db.String(255))
    streetAddress = db.Column(db.String(255))
    addInfo = db.Column(db.String(255))
    date_created = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id', name='fk_user_customer_id'), nullable=True)