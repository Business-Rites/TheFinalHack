#create wtf forms
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, IntegerField, PasswordField, BooleanField,SubmitField, TextAreaField, SelectField, validators,TextField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from wtforms.fields.html5 import EmailField, DateField

#-----------------------------------------------------------------------------------------------------------------#
#                                            Home Blueprint Forms                                                 #
#-----------------------------------------------------------------------------------------------------------------#


class AddToCart(FlaskForm):
    quantity = IntegerField('Quantity')
    submit = SubmitField('Submit')


class ServiceInvForm(FlaskForm):
    invDesc = TextAreaField('Services Desc')
    amount = IntegerField('Amount')
    submit = SubmitField('Submit')


class CompanyProfileForm(FlaskForm):
    cmpyName = StringField('Company Name')
    cmpyEmail = StringField('Email')
    cmpyPlotNo = StringField('Plot Number')
    cmpyCity = StringField('City')
    cmpyCountry = StringField('Country')
    cmpyAddress = StringField('Address')
    cmpyPhone = IntegerField('Phone')
    cmpyBankName = StringField('Bank Name')
    cmpyBeneficiaryName = StringField('Beneficiary Name')
    cmpyBeneficiaryAccNo = IntegerField('Beneficiary Account Number')
    cmpyBankBranchNo = IntegerField('Branch Number')
    submit = SubmitField('Submit')

class QuotationForm(FlaskForm):
    quoProduct = StringField('Product/Service Name')
    quoQuantity = IntegerField('Quantity')
    quoPrice = IntegerField('Price')
    quoAddDiscount = IntegerField('Add Discount')
    quoNotes_Terms = TextAreaField('Notes/Terms')
    submit = SubmitField('Submit')

class InvoiceForm(FlaskForm):
    invDueDate = StringField('Payment Due Date')
    invProduct = StringField('Product/Service Name')
    invQuantity = IntegerField('Quantity')
    invPrice = IntegerField('Price')
    invAddDiscount = IntegerField('Add Discount')
    invNotes_Terms = TextAreaField('Notes/Terms')
    submit = SubmitField('Submit')

class ReceiptsForm(FlaskForm):
    recProduct = StringField('Product/Service Name')
    recQuantity = IntegerField('Quantity')
    recPrice = IntegerField('Price')
    recNotes_Terms = TextAreaField('Notes/Terms')
    submit = SubmitField('Submit')


#SERVICES---------------------------------------------------------------------------------------------------------
class reqServiceForm(FlaskForm):
    serviceProduct = StringField('Product Name')
    serviceType = SelectField('Type of Service', choices=[('Air Cons', 'Air Cons'),
                                                          ('Freezers', 'Freezers'),
                                                          ('Stoves', 'Stoves'),
                                                          ('Fridges', 'Fridges'),
                                                          ('Cold Room', 'Cold Room'),
                                                          ('Washing Machine', 'Washing Machine'),
                                                          ('Tumble Dryers', 'Tumble Dryers'),
                                                          ('Ice Machines', 'Ice Machines'),
                                                          ('Vehicle Regassing', 'Vehicle Regassing'),
                                                          ('Other', 'Other')
                                                          ])
    description = TextAreaField('Description')
    address = StringField('Description')
    appointment = DateField('Date', format='%Y-%m-%d')
    callOut = SelectField('Request Callout', choices=[('Yes', 'Yes'), ('No', 'No')])
    submit = SubmitField('Submit')

class PostForm(FlaskForm):
    title = StringField('title')
    content = TextAreaField('Name')
    submit = SubmitField('Submit')

class CommentForm(FlaskForm):
    content = TextAreaField('Name')
    submit = SubmitField('Reply')


#ENDSERVICES-------------------------------------------------------------------------------------------------------

class AddproductForm(FlaskForm):
    name = StringField('Name')
    price = IntegerField('Price')
    discount = IntegerField('Discount')
    stock = IntegerField('Stock')
    description = StringField('Description')
    image1 = FileField('Image')
    image2 = FileField('Image')
    image3 = FileField('Image')
    submit = SubmitField('Submit')

class UpdateproductForm(FlaskForm):
    name = StringField('Name')
    price = IntegerField('Price')
    stock = IntegerField('Stock')
    description = StringField('Description')
    image = FileField('Image')
    submit = SubmitField('Submit')


##############################################################################################################
class AddsalesForm(FlaskForm):
    cust_fname = StringField('First Name', validators=[DataRequired(),Length(min=2,max=50,message="Must between 2 to 50 characters")])
    cust_lname = StringField('Last Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    cust_phone_no = StringField('Customer Phone Number', [DataRequired()])
    product_code = StringField('Product Code', [DataRequired()])
    qnt = IntegerField('Quantity', [DataRequired()])
    warranty_status = StringField('Warranty Status')
    delivery = BooleanField("Delivery")
    submit = SubmitField('Submit')

class UpdatesalesForm(FlaskForm):
    cust_fname = StringField('First Name', validators=[DataRequired()])
    cust_lname = StringField('Last Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    cust_phone_no = StringField('Customer Phone Number', [DataRequired(),Length(min=8,max=50,message="Must between 2 to 50 characters")])
    product_code = StringField('Product Code', [DataRequired()])
    qnt = IntegerField('Quantity', [DataRequired()])
    warranty_status = StringField('Warranty Status')
    delivery = BooleanField("Delivery")
    submit = SubmitField('Submit')



class AddpurchaseForm(FlaskForm):
    product_name = StringField('product_name')
    product_code = StringField('product_code')
    pro_qnt = IntegerField('pro_qnt')
    pro_price = IntegerField('pro_price')
    payment_terms = StringField('payment_terms')
    submit = SubmitField('Submit')


class exp_typeForm(FlaskForm):
    exptype = StringField('exptype')
    submit = SubmitField('Submit')

class asset_typeForm(FlaskForm):
    assetType = StringField('asstype')
    submit = SubmitField('Submit')

class add_expenseForm(FlaskForm):
    description = StringField('description')
    #paymentStatus = SelectField('Payment Status', choices=[('Paid', 'Paid'), ('Credit', 'Credit')])
    #paymentMethod = SelectField('Payment Method', choices=[('Cash', 'Cash'), ('Bank', 'Bank')])
    amount = IntegerField('amount')
    date = DateField('Date', format='%Y-%m-%d')
    submit = SubmitField('Submit')


class add_FixedAssetForm(FlaskForm):
    name = StringField('name')
    description = StringField('description')
    usefulLife = StringField('usefulLife')
    amount = IntegerField('amount')
    date = DateField('Date', format='%Y-%m-%d')
    submit = SubmitField('Submit')

#######################################################################################################
class MessageForm(FlaskForm):
    message = TextAreaField(label =('Message'), validators=[
        DataRequired(), Length(min=0, max=140)])
    submit = SubmitField('Submit')

class AddCategory(FlaskForm):
    name = StringField('Category Name', validators=[DataRequired()])
    submit = SubmitField('Submit')

class AddBrand(FlaskForm):
    name = StringField('Brand Name', validators=[DataRequired()])
    submit = SubmitField('Submit')

class CustomerForm(FlaskForm):
    firstName = TextField('firstName', validators=[DataRequired()])
    lastName = TextField('lastName', validators=[DataRequired()])
    phone = TextField('contact', validators=[DataRequired()])
    companyName = TextField('companyName')
    postalAddress = TextField('postalAddress', validators=[DataRequired()])
    streetAddress = TextField('streetAddress', validators=[DataRequired()])
    addInfo = TextField('addInfo')
    submit = SubmitField('Submit')